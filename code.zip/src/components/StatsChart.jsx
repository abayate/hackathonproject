import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, BarElement, CategoryScale, LinearScale } from 'chart.js';

Chart.register(BarElement, CategoryScale, LinearScale);

const StatsChart = ({ user, bot }) => {
  const data = {
    labels: ['User', 'Bot'],
    datasets: [
      {
        label: 'Messages',
        data: [user, bot],
        backgroundColor: ['#007bff', '#00c6ff']
      }
    ]
  };

  return <Bar data={data} />;
};

export default StatsChart;