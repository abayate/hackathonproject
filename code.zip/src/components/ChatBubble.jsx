import React from 'react';
import './ChatBubble.css';

const ChatBubble = ({ text, isBot }) => {
  return (
    <div className={`chat-bubble ${isBot ? 'bot' : 'user'}`}>
      {text.split('\n').map((line, index) => (
        <p key={index}>{line}</p>
      ))}
    </div>
  );
};

export default ChatBubble;